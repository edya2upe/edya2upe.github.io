

class ArbolBinario:
	def __init__(self, dato=None):
		self.__dato				 = dato
		self.__hijo_izquierdo 	 = None
		self.__hijo_derecho      = None
	
	def getDato(self):
		return self.__dato		
	def getHijoIzquierdo(self):
		return  self.__hijo_izquierdo	
	def getHijoDerecho(self): 
		return self.__hijo_derecho	
	def esHoja(self):
		return self.__hijo_izquierdo == None and self.__hijo_derecho == None
	def setDato(self):
		self.__dato = dato
	def setHijoIzquierdo(self, arbol):
		self.__hijo_izquierdo = arbol	
	def setHijoDerecho(self, arbol):
		self.__hijo_derecho = arbol		
	def eliminarHijoIzquierdo(self):
		self.__hijo_izquierdo = None
	def eliminarHijoDerecho(self):
		self.__hijo_derecho = None


