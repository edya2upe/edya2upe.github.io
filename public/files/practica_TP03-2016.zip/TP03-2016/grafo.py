
class Vertice():
	def __init__(self,dato = None, posicion = None):
		self.dato 		= dato
		self.posicion 	= posicion
		self.adyacentes = []
		
	def getDato(self):return self.dato
	def setDato(self,dato): self.dato = dato
	def getPosicion(self):return self.posicion
	def setPosicion(self,posicion):self.posicion = posicion
	def obtenerAdyacentes(self):return self.adyacentes
	def esAdyacente(self,vertice):
		for arista in self.adyacentes:
			if arista.verticeDestino().getPosicion() == vertice.getPosicion():
				return True		
		return False
	def peso(self,vertice):
		for arista in self.adyacentes:
			if arista.verticeDestino().dato() == vertice.dato():
				return arista.peso()
		return -1


	
class Arista():
	def __init__(self,destino = None, peso = None):
		self.destino = destino
		self.peso 	 = peso
	def verticeDestino(self):return self.destino
	def peso(self):return self.peso
	
	def setDestino(self,vertice):self.destino = vertice
	def setPeso(self,peso): self.peso = peso
	
	
		
			


class Grafo():
	def __init__(self):
		self.vertices = []
	
	def agregarVertice(self,vertice): 
		self.vertices.append(vertice)
		vertice.setPosicion(len(self.vertices)-1)
		
	def eliminarVertice(self,vertice):
		if len(self.vertices)>0:
			posicion = 0
			for v in self.vertices:
				if v.dato() == vertice.dato():
					break
				posicion +=1
			if len(self.vertices)>1:
				self.vertices = self.vertices[:posicion] + self.vertices[posicion+1:]
				for indice in range(posicion,len(self.vertices)):
					self.vertices[indice].setPosicion(indice)					
			else:
				self.vertices = []
	def conectar(self,vertice1, vertice2):
		vertice1.agregarAdyacente(Arista(vertice2,0))
	def desconectar(self,vertice1,vertice2):
		vertice1.eliminarAdyacente(vertice2)
	
	def esAdyacente(self,vertice1,vertice2):
		return vertice1.esAdyacente(vertice2)
	def esVacio(self):return len(self.vertices) == 0
	
	def listaDeVertices(self):return self.vertices
	def listaDeAdyacentes(vertice): return vertice.obtenerAdyacentes()
	


		
		
	
