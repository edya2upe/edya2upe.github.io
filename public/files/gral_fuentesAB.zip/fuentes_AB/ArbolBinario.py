

class ArbolBinario():
	def __init__(self, dato = None):
		self._dato = dato
		self.hijoIzquierdo = None
		self.hijoDerecho = None
		
	def getDato(self):return self._dato		
	def getHijoIzquierdo(self):return  self.hijoIzquierdo	
	def getHijoDerecho(self): return self.hijoDerecho		
	def agregarHijoIzquierdo(self, arbol):self.hijoIzquierdo = arbol	
	def agregarHijoDerecho(self, arbol):self.hijoDerecho = arbol		
	def eliminarHijoIzquierdo(self):self.hijoIzquierdo = None
	def eliminarHijoDerecho(self):self.hijoDerecho = None

