class ArbolGeneral():
	def __init__(self,dato = None):
		self.__dato 	= dato
		self.__hijos 	= []
	def setDatoRaiz(self,dato): self.__dato = dato
	def getDatoRaiz(self):return self.__dato
	def getHijos(self): return self._hijos
	def agregarHijo(self,arbol): self.__hijos.append(arbol)
	def eliminarHijo(self,arbol):
		""" Implementar el metodo """
		return None
	def esHoja(self):
		""" Implementar el metodo """
		return None
	def altura(self):
		""" Implementar el metodo """
		return None
	def ancho(self):
		""" Implementar el metodo """
		return None
	def nivel(self,dato):
		""" Implementar el metodo """
		return None
	

	
