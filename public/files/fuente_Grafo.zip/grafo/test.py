
from vertice import Vertice
from arista import Arista
from grafo import Grafo



v1 = Vertice(1)
v2 = Vertice(2)
v3 = Vertice(3)
v4 = Vertice(4)
v5 = Vertice(5)
v6 = Vertice(6)
v7 = Vertice(7)
v8 = Vertice(8)

g = Grafo()

g.agregarVertice(v1)
g.agregarVertice(v2)
g.agregarVertice(v3)
g.agregarVertice(v4)
g.agregarVertice(v5)
g.agregarVertice(v6)
g.agregarVertice(v7)
g.agregarVertice(v8)

g.conectar(v1,v3)
g.conectar(v1,v4)
g.conectar(v1,v8)
g.conectar(v3,v1)
g.conectar(v2,v3)
g.conectar(v2,v5)
g.conectar(v2,v6)
g.conectar(v4,v2)
g.conectar(v4,v7)
g.conectar(v5,v1)
g.conectar(v5,v8)
g.conectar(v6,v3)
g.conectar(v7,v8)
g.conectar(v8,v2)

