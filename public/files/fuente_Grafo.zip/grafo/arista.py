
class Arista():
	def __init__(self,destino = None, peso = None):
		self.destino = destino
		self.peso 	 = peso
	def verticeDestino(self):return self.destino
	def peso(self):return self.peso
	
	def setDestino(self,vertice):self.destino = vertice
	def setPeso(self,p): self.peso = p
	
