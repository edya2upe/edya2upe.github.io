from arista import Arista
class Vertice():
	def __init__(self,dato = None, posicion = None):
		self.dato 		= dato
		self.posicion 	= posicion
		self.adyacentes = []
		
	def getDato(self):return self.dato
	def setDato(self,dato): self.dato = dato
	def getPosicion(self):return self.posicion
	def setPosicion(self,p):self.posicion = p
	def obtenerAdyacentes(self):return self.adyacentes
	def agregarAdyacente(self,arista): self.adyacentes.append(arista)
	def eliminarAdyacente(self,vertice):
		pos = 0
		for arista in self.adyacentes:
			if arista.vertice.dato() == vertice.dato():
				del self.adyacentes[pos]
				break
			pos += 1
	def esAdyacente(self,vertice):
		for arista in self.adyacentes:
			if arista.verticeDestino().dato() == vertice.dato():
				return True		
		return False
	def peso(self,vertice):
		for arista in self.adyacentes:
			if arista.verticeDestino().dato() == vertice.dato():
				return arista.peso()
		return -1
	
		
