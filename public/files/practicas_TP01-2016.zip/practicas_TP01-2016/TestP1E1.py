import unittest
from practica1 import  funcionFor,funcionWhile,funcionNoIter

class TP1E1Test(unittest.TestCase):
	
	def setUp(self):
		self.numero1 	= 10
		self.numero2  	= 100        
	
	def testFuncionForAMenorB( self ):
		self.assertEquals( funcionFor( self.numero1, self.numero2 ), range( self.numero1, self.numero2 + 1 ) )
		
	def testFuncionForBMenorA( self ):
		self.assertEquals( funcionFor( self.numero2, self.numero1 ), range( self.numero1, self.numero2 + 1 ) )
	
	def testFuncionForAIgualB(self):
		self.assertEquals(funcionFor(self.numero1,self.numero1),range(self.numero1, self.numero1 +1 ))
		
	def testFuncionWhileAMenorB( self ):
		self.assertEquals( funcionWhile( self.numero1, self.numero2 ), range( self.numero1, self.numero2 + 1 ) )
		
	def testFuncionWhileBMenorA( self ):
		self.assertEquals( funcionWhile( self.numero2, self.numero1 ), range( self.numero1, self.numero2 + 1 ) )
	
	def testFuncionWhileAIgualB(self):
		self.assertEquals(funcionWhile(self.numero1,self.numero1),range(self.numero1, self.numero1 +1 ))
		
	def testFuncionNoIterAMenorB( self ):
		self.assertEquals( funcionNoIter( self.numero1, self.numero2 ), range( self.numero1, self.numero2 + 1 ) )
		
	def testFuncionNoIterBMenorA( self ):
		self.assertEquals( funcionNoIter( self.numero2, self.numero1 ), range( self.numero1, self.numero2 + 1 ) )
	
	def testFuncionNoIterAIgualB(self):
		self.assertEquals(funcionNoIter(self.numero1,self.numero1),range(self.numero1, self.numero1 +1 ))
		
	
if __name__ == '__main__':
	unittest.main()
