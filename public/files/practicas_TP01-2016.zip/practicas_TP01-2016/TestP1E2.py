import unittest
from practica1 import  multiplos

class TP1E2Test(unittest.TestCase):
	
	def setUp(self):
		self.numero1 	= 5
		self.lista1 	= [5,10,15,20,25]
		self.numero2 	= 1
		self.lista2 	= [1]
		self.numero3 	= 15
		self.lista3 	= [15,30,45,60,75,90,105,120,135,150,165,180,195,210,225]			
	
	def testMultuplosCon5( self ):
		self.assertEquals( multiplos( self.numero1 ), self.lista1 )
	
	def testMultuplosCon1( self ):
		self.assertEquals( multiplos( self.numero2 ), self.lista2 )
		
	def testMultuplosCon15( self ):
		self.assertEquals( multiplos( self.numero3 ), self.lista3 )
		
	
	
if __name__ == '__main__':
	unittest.main()
