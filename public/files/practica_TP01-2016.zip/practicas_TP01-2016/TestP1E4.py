import unittest
from practica1 import  conReturn,conParametro

class TP1E4Test(unittest.TestCase):
	
	def setUp(self):
		self.maximo1 	= 225
		self.minimo1 	= -120
		self.promedio1 	= 105
		self.lista1		= [15,-120,30,45,60,75,90,105,120,135,150,165,180,195,210,225]			
		self.resultado1 = [self.maximo1,self.minimo1, self,self.promedio1]
		
		self.maximo2 	= 100
		self.minimo2 	= -100
		self.promedio2 	= 1
		self.lista2		= [-5,-25,-100,100,25,5,7]			
		self.resultado2 = [self.maximo2,self.minimo2, self,self.promedio2]
	
	def testConReturn( self ):
		self.assertEquals( conReturn( self.lista1 ), self.resultado1 )
		self.assertEquals( conReturn( self.lista2 ), self.resultado2 )
	
	def testConParametro( self ):
		resultado = []
		conParametro(self.lista1,resultado)
		self.assertEquals( resultado, self.resultado1)
		resultado = []
		conParametro(self.lista2,resultado)
		self.assertEquals( resultado, self.resultado2)
		
	
	
if __name__ == '__main__':
	unittest.main()
